//아이콘설명
function displayChange(arg1){
	var displayYN = document.getElementById(arg1).style.display;
	document.getElementById(arg1).style.display = (displayYN=="none")?"table-row":"none";
}

