// ui 관련
$(document).ready(function(){
	$('a').click(function(e){
		if($(this).attr('href') === '#none'){
			e.preventDefault();
		}
	})
	

	//qna 아코디언
	$('.faq_block>dl>dt a').click(function(){
		$curr_dl = $(this).parent().parent();
		if($curr_dl.hasClass('opened')){
			$(this).html('<span>열기<span class="ico_arr_down"></span></span>');
			$('>dd', $curr_dl).slideUp(300, function(){
				$curr_dl.removeClass('opened');
			});
		}else{
			$open_dl = $('.faq_block>dl.opened');
			$('>dt a', $open_dl).html('<span>열기<span class="ico_arr_down"></span></span>');
			$('>dd', $open_dl).slideUp(300, function(){
				$open_dl.removeClass('opened');
			});

			$(this).html('<span>닫기<span class="ico_arr_up"></span></span>');
			$('>dd', $curr_dl).slideDown(300, function(){
				$curr_dl.addClass('opened');
			});
		}
	});


});


