/*
	UI jQuery by.notteng
*/
var Browser = {chk : navigator.userAgent.toLowerCase()}
Browser = {ie : Browser.chk.indexOf('msie') != -1, ie6 : Browser.chk.indexOf('msie 6') != -1, ie7 : Browser.chk.indexOf('msie 7') != -1, ie8 : Browser.chk.indexOf('msie 8') != -1, ie9 : Browser.chk.indexOf('msie 9') != -1, ie10 : Browser.chk.indexOf('msie 10') != -1, ie11 : Browser.chk.indexOf('msie 11') != -1, opera : !!window.opera, safari : Browser.chk.indexOf('safari') != -1, safari3 : Browser.chk.indexOf('applewebkir/5') != -1, mac : Browser.chk.indexOf('mac') != -1, chrome : Browser.chk.indexOf('chrome') != -1, firefox : Browser.chk.indexOf('firefox') != -1, chrome : Browser.chk.indexOf('chrome') != -1}  
// mobile case :: scroll size
var mobile = (/iphone|ipod|ipad|android|blackberry|mini|windows\sce|palm/i.test(navigator.userAgent.toLowerCase()));
function setCookie(name,value,expiredays){
	var todayDate = new Date();
	todayDate.setDate(todayDate.getDate() + expiredays);
	document.cookie = name + "=" +escape(value) + "; path=/; exoures=" + todayDate.toGMTString() + ";"
}
if (window.console == undefined) {console={log:function(){} };}
//말줄임
(function($) {
	$.fn.ellipsis = function()	{
		return this.each(function(){
			var el = $(this);
			var text = el.text();
			var t = $(this.cloneNode(true)).removeClass('ellipsis-muti').hide().css({'position':'absolute','overflow':'visible','width':el.width(),'word-break':'normal'});
			el.after(t);
			//console.log('multi',t.height(),' > ',el.height(), text);
			el.removeClass('multi');
			if(t.height() > 22 && t.height() > el.height()){
				el.addClass('multi');
			}
			t.remove();
		});
	};
})(jQuery);
var deviceW = 1023;
var UI = UI || {};
$( document ).ready(function() {
UI = {
	init : function(){
		var scrollTop, winW, winH, headerH;
		$win = $(window);
		$doc = $(document);
		$html = $('html');
		$body = $('body');
		$wrap = $('#wrapper');
		$header = $('#header');
		$ham = $('.btn-hamburger');
		$crumbs = $('.breadcrumbs > li');
		$select = $('.selectbox');
		UI.ini.init();					//시작 셋팅
		UI.customScroll.init();	//스크롤 플러그인
		UI.SELECT.init();			//셀렉트박스
		UI.TAB.init();				//탭
		UI.ACCODIAN.init();		//아코디언
		UI.POP.init();				//popup open,close
		UI.GNB.init();				//header관련 액션
		UI.GALLEY.init();			//이미지 갤러리, 비디오 갤러리
		UI.PROADD.init();			//제품등록 추가
		UI.LANG.init();				//언어팝업
		UI.mobileTable.init();		//아코디언 테이블
		placeholders();
	},
	ini : {
		init : function(){
			var skip = '<a href="#content" accesskey="1" title="브라우저에 따라 Alt + 1 또는 Alt + Shift + 1 또는 Shift + Esc + 1 후 Enter를 치시면 본문영역으로 바로갑니다." class="skip">메뉴건너뛰고 본문 바로가기</a>';
			$wrap.prepend(skip);
			//디바이스별 클래스 추가
			if (mobile) {
				$("body").addClass("deviceMobile");
			} else {
				$("body").addClass("deviceDesk");
				if(Browser.ie || Browser.ie6 || Browser.ie7 || Browser.ie8){
					$("body").addClass("ie8-below");
				}
				if(Browser.ie || Browser.ie6 || Browser.ie7 || Browser.ie8 || Browser.ie9 || Browser.ie10){
					$("body").addClass("ie10-below");
				}
				if(Browser.ie9){
					$("body").addClass("ie9");
				}
		   }
		   if($('html').attr('lang') == 'fa'){
			    setTimeout(function(){$('.swiper-pagination').attr('dir','rtl')},1000);

			}
		   $win.on('scroll',function(){
				UI.ini.winScroll();
		   });
		   $win.on('resize',function(){
				UI.ini.resizeWin();
			});
		   $doc.on('mousedown touchstart',function(e){
			   var $tar = $(e.target);
			   UI.ini.winClick($tar);
		   });
		   //dimed클릭
		   $doc.on('click','.layerpop-wrap',function(e){
			   var $tar = $(e.target)
			   var $par = $tar.closest('.pop-container');
			   //console.log('.document-dimed ', $par.is(':visible'),$tar.hasClass('btn-option'), $tar.hasClass('btn-del'));
			   if(!$par.is(':visible')){
				   if($tar.hasClass('btn-option') || $tar.hasClass('btn-del')){}
				   else{UI.POP.close($('.layerpop-wrap'));}
				}
		   });
		   //스킵버튼
		   $doc.on('click','.skip',function(e){
			   $('#content').find('a:visible:first').focus();
			   e.preventDefault();
		   });
		   //토글 버튼
		   $doc.on('click','a',function(e){
			   var $this = $(e.currentTarget);
			   var wrap = $(this).attr('data-wrap');
			   var anchor = $(this).attr('data-anchor');
			   var toggle = $(this).attr('data-toggle');
			   if(toggle){
				   if($this.hasClass('tooltip') && $ham.is(':hidden')){
				   }else{
					   if($(this).hasClass('on')){
							$(this).removeClass('on');
					   }else{
						   $('.tooltip').removeClass('on');
						   $(this).addClass('on');
					   }
				   }
				   e.preventDefault();
			   }
			   if(anchor){
					if(!wrap){
						anchorFn($(this).attr('href'));
						e.preventDefault();
					}
			   }
		   });
		   // ie9 placeholder
		   if($body.hasClass('ie9')){
			   $doc.on('focus',':text, textarea',function(){
					if($(this).val() == $(this).attr("placeholder")){
					  $(this).val("");
					}
			   });
			   $doc.on('blur',':text, textarea',function(){
					if( $(this).val() == ""){
					  $(this).val($(this).attr("placeholder"));
					}
			   });
		   }
		   
		   // app.js 실행으로 변경 ( i18 로딩으로인한 이슈로 변경) 
		   // UI.ini.resizeWin();  
		},
		resizeWin:function(){
			winW = $win.innerWidth();
			winH = $win.innerHeight();
			$mScroll = $('.scroll-m-x');
			var navScollH;
			if($ham.is(':visible')){
				headerH = 85;
				//$header.find('.tab > li:eq(0) > a').trigger('click');
				//$header.find('.expend-group').hide();
				//$ham.removeClass('close');
				$header.find('.scroll-wrap').show();
				$('.max-h-fit .max-h').removeAttr('style');
				scrollX_w($mScroll.find('.scroll-x-list'));
				if(!$mScroll.hasClass('mCSB_container')){
					UI.customScroll.scrollX($mScroll);
				}

				$('.nav-list > .product-banner').show();
				if(!$ham.hasClass('close')){
					$header.find('.expend-group').hide();
				}
				navScollH = winH-headerH-$('#header .util_wrap').height()- $('#header .tab-wrap').height();
			}else{
				if($header.hasClass('fixed')){
					headerH = 70;
				}else{
					headerH = 90;
				}
				navScollH = winH-headerH;
				$header.find('.expend-group').show();
				$header.find('.scroll-wrap').hide();
				UI.GNB.crumbs_reset();
				UI.customScroll.destroy($mScroll);
				$mScroll.find('.scroll-x-list').removeAttr('style');
			}
			pro_setting($('.mo-pop'));
			scrollX_w($('.scroll-x .scroll-x-list'));
			//if($('.layerpop-wrap').is(':visible') || $('.full-pop-wrap').is(':visible')){}else{UI.ini.winUnlock();}
			maxBoxSet();
			if($body.hasClass('lock')){
				$body.css({'height':winH});
			}
			if($('#ui-datepicker-div').is(':visible')){
				$('.datepicker').datepicker( "hide" );
			}
			$('.tooltip').removeClass('on');
			//console.log('navScollH : ',navScollH,winH, headerH, $('#header .util_wrap').height(),$('#header .tab-wrap').height());
			if($html.hasClass('agent-app')){
				$header.find('.scroll-wrap').css({'max-height':navScollH-40});
			}else{
				$header.find('.scroll-wrap').css({'max-height':navScollH});
			}
			scrollY_set();
			$(".ellipsis-muti").ellipsis();
		},
		winScroll:function(){
			var bnrH = 100;
			scrollTop = $win.scrollTop();
			//console.log('scrollTop',scrollTop);
			if($('.belt-banner').is(':visible')){
				bnrH = 200
			}
			if(scrollTop > bnrH){
				if(!$header.hasClass('fixed')){
					$header.addClass('fixed');
					//TweenMax.fromTo($header,0.3,{top:-90},{top:0, ease:Power2.easeOut});
				}
			}else{
				$header.removeClass('fixed');
			}
		},
		winClick:function($tar){
			if(!$tar.is($select.find('a'))){
				//console.log('select out');
				UI.SELECT.close($select,true);
			}
			if(!$tar.is($crumbs.find('a, span'))){
				UI.GNB.crumbs_reset();
			}
			if(!$tar.is($doc.find('.tooltip, .icon-tooltip'))){
				$('.tooltip').removeClass('on');
			}
		},
		winLock:function(){
			console.log('winLock');
			$body.css({'overflow':'hidden','height':winH});
			$body.addClass('lock');
			//disableScroll();

		},
		winUnlock:function(){
			console.log('winUnlock');
			$body.css({'overflow':'visible','height':'auto'});
			$body.removeClass('lock');
			if($('.document-dimed').is(':visible')){
				$('.document-dimed').remove();
			}
			//enableScroll();
		}
	},
	customScroll : {
		init : function(){
			$textareaObj = $('form .textarea-wrapper');
			$scrollY = $('.content .scroll-y');
			$scrollX = $('.content .scroll-x');
			if($textareaObj.length > 0){
				$textareaObj.each(function(){
					UI.customScroll.textareaScroll(this);
				});
			}
			if($scrollY.length > 0){
				$scrollY.each(function(){
					if($(this).closest('header').attr('id') == 'header'){
						if($body.hasClass('deviceDesk')){
							UI.customScroll.scrollY(this);
						}
					}else{
						UI.customScroll.scrollY(this);
					}
				});
			}
			if($scrollX.length > 0){
				$scrollX.each(function(){
					UI.customScroll.scrollX(this);
				});
			}
		},
		textareaScroll : function(obj){
			var $textareaWrapper=$(obj);
			var $textarea=$textareaWrapper.children('textarea');
			var $textareaClone=$textareaWrapper.children('.textarea-clone');
			var textareaLineHeight=parseInt($textarea.css("line-height"));
			$textarea.on('focusin',function(){
				$textareaWrapper.addClass('line0');
			});
			$textarea.on('focusout',function(){
				$textareaWrapper.removeClass('line0');
			});
			$textareaWrapper.mCustomScrollbar({
				scrollInertia:0,
				advanced:{autoScrollOnFocus:false},
				mouseWheel:{disableOver:["select","option","keygen","datalist",""]},
				keyboard:{enable:false},
				snapAmount:textareaLineHeight
			});
			$textarea.bind("keyup keydown",function(e){
				var $this=$(this);
				var textareaContent=$this.val()
				var clength=textareaContent.length
				var cursorPosition=$textarea.getCursorPosition();
				textareaContent="<span>"+textareaContent.substr(0,cursorPosition)+"</span>"+textareaContent.substr(cursorPosition,textareaContent.length);
				textareaContent=textareaContent.replace(/\n/g,"<br />");
				$textareaClone.html(textareaContent+"<br />");
				$this.css("height",$textareaClone.height());
				var textareaCloneSpan=$textareaClone.children("span"),textareaCloneSpanOffset=0,
					viewLimitBottom=(parseInt($textareaClone.css("min-height")))-textareaCloneSpanOffset,viewLimitTop=textareaCloneSpanOffset,
					viewRatio=Math.round(textareaCloneSpan.height()+$textareaWrapper.find(".mCSB_container").position().top);
				if(viewRatio>viewLimitBottom || viewRatio<viewLimitTop){
					if((textareaCloneSpan.height()-textareaCloneSpanOffset)>0){
						$textareaWrapper.mCustomScrollbar("scrollTo",textareaCloneSpan.height()-textareaCloneSpanOffset-textareaLineHeight);
					}else{
						$textareaWrapper.mCustomScrollbar("scrollTo","top");
					}
				}
			});
		},
		scrollY : function(obj){
			//console.log($('body').hasClass('deviceMobile'),$(obj).hasClass('country-cont'),$ham.is(':visible'));
			if($(obj).hasClass('country-cont') && $ham.is(':visible')){
			}else{
				$(obj).mCustomScrollbar({
					axis:"y", // vertical scrollbar
					setTop:0,
					callbacks:{
						onInit:function(){
							$(obj).mCustomScrollbar('scrollTo','top');
						}
					}
				});
			}
		},
		scrollX : function(obj){
			if(mobile){
				$('.scroll-m-x, .scroll-x').css({'overflow-x':'auto','padding-bottom':'10px'});
			}else{
				if($('html').attr('lang') == 'fa'){
					$(obj).mCustomScrollbar({
						axis:"x", // horizontal scrollbar
						alwaysShowScrollbar:1,
						setLeft:0,
						mouseWheel:{invert: true},
						callbacks:{
							onBeforeUpdate:function(){
								$(obj).mCustomScrollbar('scrollTo','last');
							},
							onOverflowX:function(){
								var $parX = $(obj).parent();
								if($parX.hasClass('scroll-x-area')){if(!$parX.hasClass('overflow')){$parX.addClass('overflow');}}
								$(obj).find('.mCSB_draggerContainer').show();
								//console.log('onOverflowX');
							},
							onOverflowXNone:function(){
								var $parX = $(obj).parent();
								if($parX.hasClass('scroll-x-area')) {$parX.removeClass('overflow');}
								$(obj).find('.mCSB_draggerContainer').hide();
								//console.log('onOverflowXNone', $parX);
							}

						}
					});
				}else{
					$(obj).mCustomScrollbar({
						axis:"x", // horizontal scrollbar
						alwaysShowScrollbar:1,
						setLeft:0,
						callbacks:{
							onBeforeUpdate:function(){
								$(obj).mCustomScrollbar('scrollTo','first');
							},
							onOverflowX:function(){
								var $parX = $(obj).parent();
								if($parX.hasClass('scroll-x-area')){if(!$parX.hasClass('overflow')){$parX.addClass('overflow');}}
								$(obj).find('.mCSB_draggerContainer').show();
								//console.log('onOverflowX');
							},
							onOverflowXNone:function(){
								var $parX = $(obj).parent();
								if($parX.hasClass('scroll-x-area')) {$parX.removeClass('overflow');}
								$(obj).find('.mCSB_draggerContainer').hide();
								//console.log('onOverflowXNone', $parX);
							}

						}
					});
				}
			}
		},
		scrollXY : function(obj){
			$(obj).hide();
			$(obj).mCustomScrollbar({
				axis:"yx", // horizontal scrollbar
				setTop: 0,
				setLeft: 0,
				documentTouchScroll: true,
				callbacks:{
					onBeforeUpdate:function(){
						$(obj).mCustomScrollbar('scrollTo','first');
					}
				}
			});
		},
		destroy :function(obj){
			if(obj.hasClass('mCustomScrollbar')){
				$(obj).mCustomScrollbar('destroy'); // remove scrollbar
			}
		}
	},
    SELECT : {
		init : function(){
		   this.event();
		   this.set();
		},
		event : function(obj){
			$doc.on('focusin','.selectbox.default > select',function(e){
				var $this = $(e.currentTarget);
				var $par = $this.parent();
				$par.addClass('focus');
			 });
			 $doc.on('focusout','.selectbox.default > select',function(e){
				var $this = $(e.currentTarget);
				var $par = $this.parent();
				$par.removeClass('focus');
			 });
			$doc.on('click','.selectbox.default > select',function(e){
				var $this = $(e.currentTarget);
				var $par = $this.parent();
				 if($par.hasClass('open')){
					 $par.removeClass('open');
				 }else{
					 $par.addClass('open');
				 }
			 });
			 $doc.on('change','.selectbox.default > select',function(e){
				 var $this = $(e.currentTarget);
				 var $par = $this.parent();
				 var $tar = $par.children('.select-value');
				 $tar.text($this.find('option:selected').text());
			 });
			 $doc.on('click','.selectbox:not(.default) .select-value',function(e){
				 var $this = $(e.currentTarget);
				 var $par = $this.parent();
				 if($par.hasClass('open')){
					 UI.SELECT.close($par,false);
				 }else{
					 UI.SELECT.open($par);
				 }
				 e.preventDefault();
			 });
			 $doc.on('click','.selectbox:not(.default) .option  a',function(e){
				 var $this = $(e.currentTarget);
				 var $par = $this.closest('.selectbox');
				 var txt = $this.text();
				 UI.SELECT.close($par,true);
				 //$par.children('.select-value').text(txt);
				 //e.preventDefault();
			 });
		},
		open : function($tar){
			var $opt = $tar.find('.option');
			UI.SELECT.close($('selectbox:not(.default)').filter('.open'), false);
			$tar.addClass('open');
			var _height = $tar.data("height");
			$tar.find('.option').slideDown();
			if($tar.hasClass('scroll')){
				UI.customScroll.scrollY($tar.find('.option'));
			}
		},
		close : function($tar, animate){
			$tar.removeClass('open');
			var $opt = $tar.find('.option');
			if(!animate)  $opt.hide();
			else $opt.slideUp();
			if($tar.hasClass('scroll')){
				UI.customScroll.destroy($opt)
			}
		},
		set: function(){
			$('.selectbox.default > select').each(function(e){
				var $val = $(this).parent().find('.select-value');
				$val.text($(this).find('option:selected').text());
			 });
		}
    },
	TAB : {
		init : function(){
			this.event();
			this.set();
		},
		event : function(obj){
			$doc.on('click','.tab-wrap .select-value',function(e){
				var $this = $(e.currentTarget);
				var $obj = $this.parent();
				if($this.next(".tab").is(':visible')){
					$obj.removeClass('open');
					$this.next(".tab").slideUp();
				}else{
					$obj.addClass('open');
					$this.next(".tab").slideDown();
				}
				e.preventDefault();
			});
			$doc.on('click','.tab-wrap li > a',function(e){
				var $this = $(e.currentTarget);
				var $obj = $this.closest('.tab-wrap');
				var $cont = $obj.next('.tab-container');
				var href = $this.attr('href');
				var $headtab = $($this.closest('#header'));
				console.log($headtab.index(), $headtab.hasClass('on-login'))
				if($headtab.index() > 0){
					if($headtab.hasClass('on-login')){
						$obj.find('li').removeClass('active');
						$this.parent().addClass('active');
					}
				}else{
					$obj.find('li').removeClass('active');
					$this.parent().addClass('active');
				}
				$obj.find('.select-value').text($(this).text());
				if($obj.find('.select-value').is(':visible')){
					$this.closest(".tab").slideUp();
				}
				if(href.substring(0,1) == "#"){
					$cont.find('.tab-cont').hide();
					$cont.find(href).show();
					var $scroll = $cont.find(href).closest('.mCustomScrollbar');
					if($scroll.index() > 0){
						$scroll.mCustomScrollbar("scrollTo","top",{scrollInertia:0});
					}
					//e.preventDefault();
				}
			});
		},
		set: function()
		{
			$('.tab-wrap.as-change-select').each(function(){
				var txt = $(this).find('.active > a').text();
				if(txt == ''){txt = $(this).find('.active > a').val();}
				//console.log('.tab-wrap.as-change-select',txt);
				$(this).find('.select-value').text(txt);
			});
		}
	},
	ACCODIAN : {
		init : function(){
			$acc = $('.content .accodian');
			if($acc.length > 0){
				$acc.find('li.active .answer').slideDown(200);

			}
			this.event();
		},
		event : function(){
			var accordion = this;
			$doc.on("click", '.content .accodian > li > a', function(e){
				var $tar = e.currentTarget;
				accordion.action($tar);
				$('#motorSelectPop .scroll-y').mCustomScrollbar('scrollTo',0);
				e.preventDefault();
			});
		},
		action : function(eleAcc){
			var $eleAcc = $(eleAcc).parent("li");
			var $eleAccParent = $eleAcc.closest(".accodian");
			if ($eleAcc.hasClass("active")){
				$eleAcc.find(".answer").slideUp(200, function(){
				  $eleAcc.removeClass("active");
				});
			} else {
				if ($eleAccParent.hasClass("sync")){
				  $eleAccParent.find("li").removeClass("active");
				  $eleAccParent.find(".answer:not(.active)").slideUp(200);
				}
				$eleAcc.addClass("active");
				$eleAcc.find(".answer").stop().slideDown(200, function(){
					if($body.hasClass('deviceDesk')){
						if($(this).hasClass('scroll-y')){
							UI.customScroll.destroy($(this));
							UI.customScroll.scrollY($(this));
						}
						var $par = $(this).closest('.agency-network');
						if($par.is(':visible')){
							scrollAnchor('.accodian');
						}
					}
				});
			}
		}
	},
	POP : {
		init : function(){
			$btnClose = $('.layerpop-wrap .btn-pop-close');
			this.event();
		},
		event : function(){
			var pop = this;
			$doc.on('click','.btn-layer-pop',function(e){
				var $this = $(e.currentTarget);
				var id = $this.attr('href');
				var type = $this.attr('data-type');
				var url = $this.attr('data-url');
				var func = $this.attr('data-func');
				var $con = $(id);
				if(type == 'link'){
					linkLayerPop(id, url,func);
					e.preventDefault();
				}else if(type == 'iframe'){
					var iframeUrl = $this.attr('data-iframe');
					iframeLayerPop(id, iframeUrl);
					e.preventDefault();
				}else if(type == 'product'){
					var $tar = $this.closest('.row');
					pop.open($tar.children('.layerpop-wrap'));
					e.preventDefault();
				}else if(type == 'inner'){
					pop.innerPopOpen($con);
				}else{
					pop.open($con);
					e.preventDefault();
				}
			});
			$doc.on('click','.btn-pop-close',function(e){
				var $con = $(this).closest('.layerpop-wrap');
				var $inner = $(this).closest('.inner-pop');
				if($inner.is(':visible')){
					pop.innerPopClose($inner);
				}else{
					pop.close($con);
				}
				e.preventDefault();
			});
			if($body.hasClass('ie8-below')){
				$doc.on('change','input[type="checkbox"]',function(e){
					var $tar = $(e.currentTarget);
					if($tar.is(':checked')){
						$tar.addClass('chk');
					}else{
						$tar.removeClass('chk');
					}
				});
			}
		},
		open : function(obj){
			if($('.document-dimed').length == 0){
				$body.append('<div class="document-dimed"></div>');
				obj.show();
				TweenMax.fromTo(obj.find('.pop-container'), 0.5,{y:-100},{y:0, ease:Power4.easeOut,onComplete:pop_scollset});
				placeholders();
				UI.SELECT.set();
				UI.TAB.set();
				//console.log(obj.find('.pop-container').hasClass('product-search'));
				if(obj.attr('id')=='modelFinderPop' || obj.attr('id')=='motorSelectPop'){
					if(!$('#wrapper').hasClass('main')){
						UI.ini.winLock();
					}
				}else if(obj.find('.pop-container').hasClass('product-search') || obj.attr('id') == 'modalLocationSearch'){}else{
					UI.ini.winLock();
				}
			}
		},
		close : function(obj){
			var $sx= obj.find('.scroll-x');
			var $sy= obj.find('.scroll-y');
			if($sx.is(':visible')){
				UI.customScroll.destroy($sx);
			}
			if($sy.is(':visible')){
				UI.customScroll.destroy($sy);
			}
			if($('#cookie').prop("checked")){
				setCookie("updatePop","done",1);
			}
			if(obj.hasClass('link-type')){
				obj.remove();
			}else{
				obj.hide();
			}
			TweenMax.to($('.document-dimed'), 0.3, {opacity:0,
				onComplet:function(){
					$('.document-dimed').remove();
					if(obj.attr('id')=='modelFinderPop'){
						$('#modelFinderPop').empty();
					}
					UI.ini.winUnlock();
			}});
			
		},
		innerPopOpen : function(obj){
			$('.inner-pop').hide();
			obj.show();
			TweenMax.fromTo(obj, 0.5,{y:-100},{y:0, ease:Power4.easeOut});
		},
		innerPopClose : function(obj){
			TweenMax.fromTo(obj, 0.5,{y:0},{y:-100, ease:Power4.easeOut,onComplet:function(){obj.hide();}});
		}
	},
	GALLEY : {
		init : function(){
			this.event();
		},
		event : function(){
			$doc.on('click','.gallery-ui a',function(e){
				var $par = $(e.currentTarget).closest('.gallery-ui');
				var url = $(this).attr('data-img');
				var $tar = $($(this).attr('href'));
				$par.find('li').removeClass('on');
				$(this).parent().addClass('on');
				$tar.attr({'src':url});
				//console.log('GALLEY',url);
				e.preventDefault();
			});
			$doc.on('click','.video-ui a',function(e){
				var $par = $(e.currentTarget).closest('.video-ui');
				var url = $(this).attr('data-mov');
				var $tar = $($(this).attr('href'));
				$par.find('.swiper-slide').removeClass('on');
				$(this).parent().addClass('on');
				$tar.attr({'src':url});
				e.preventDefault();
			});
		}
	},
	GNB : {
		init : function(){
			key_math = false;
			focus_num = 0;
			active_num1 = 0;
			mypage_interval = '';
			$pcmenu = $('.only-pc-menu');
			$nav = $('.nav-list .nav');
			$menu = $nav.find('li');
			$gnb_dep1 = $('.nav > li');
			$gnbmenu = $header.find('.expend-group');
			$gnbwrap = $header.find('.scroll-wrap');
			gnb_chk = false;
			$gnb_dep1.each(function(index){
				$(this).find('.depth2 > li').each(function(n){
					var row = Math.floor(n/4) + 1;
					$(this).addClass('row-'+row);
				});
			});
			$menu.each(function(index){
				if($(this).children('ul').length > 0){
					$(this).addClass('sub-visible');
				}
			});
			this.event();
		},
		event : function(){
			var mainB_play = false;
			var imgBnr = false;
			$ham.on('click',function(e){
				$menu.removeClass('on');
				if($(this).hasClass('close')){
					$(this).removeClass('close');
					if($html.attr('lang') == 'fa'){
						TweenMax.to($gnbmenu,0.3,{left:-winW,ease:Power2.easeOut,onComplete:function(){$gnbmenu.hide();}})
					}else{
						TweenMax.to($gnbmenu,0.3,{right:-winW,ease:Power2.easeOut,onComplete:function(){$gnbmenu.hide();}});
					}
					$header.removeClass('mGnb-on').css({'z-index':700});
					if(imgBnr){$('.img-type-pop').show();}
					if(mainB_play){$('.visual-pagination .btn-ctl').trigger('click');}
					UI.ini.winUnlock();
				}else{
					$(this).addClass('close');
					$gnbmenu.show();
					$menu.not('.active').children('ul').hide();
					$menu.filter('.active').addClass('on').children('ul').show();
					if($html.attr('lang') == 'fa'){
						TweenMax.fromTo($gnbmenu,0.3,{left:-winW},{left:0, ease:Power2.easeOut,onStart:function(){
						UI.ini.winLock();
					}});
					}else{
						TweenMax.fromTo($gnbmenu,0.3,{right:-winW},{right:0, ease:Power2.easeOut,onStart:function(){
						UI.ini.winLock();
					}});
					}
					$header.addClass('mGnb-on').css({'z-index':1000});
					if($('.img-type-pop').is(':visible')){
						imgBnr = true;
						$('.img-type-pop').hide();
					}else{
						imgBnr = false;
					}
					if($('.big-banner').is(':visible')){
						if(!$('.btn-ctl').hasClass('play')){
							mainB_play = true;
							$('.visual-pagination .btn-ctl').trigger('click');
						}else{
							mainB_play = false;
						}
					}
					var navScollH = winH-headerH-$('#header .util_wrap').height()- $('#header .tab-wrap').height();
					//console.log('navScollH : ',navScollH, winH, headerH, $('#header .util_wrap').height(), $('#header .tab-wrap').height());
					if($html.hasClass('agent-app')){
						$header.find('.scroll-wrap').css({'max-height':navScollH-40});
					}else{
						$header.find('.scroll-wrap').css({'max-height':navScollH});
					}
				}
				e.preventDefault();
			});
			$nav.on('click','a',function(e){
				var $par = $(this).closest('.nav-list');
				if($ham.is(':visible') || $par.hasClass('side-menu')){
					var $li = $(this).parent();
					if($li.hasClass('sub-visible')){
						var link = $(this);
						var closest_ul = link.closest("ul");
						var parallel_active_links = closest_ul.find(".on")
						var closest_li = link.closest("li");
						var link_status = closest_li.hasClass("on");
						var count = 0;
						closest_ul.find("ul").slideUp();
						parallel_active_links.removeClass("on");
						if (!link_status) {
						  closest_li.children("ul").slideDown();
						  closest_li.addClass("on");
						}
						e.preventDefault();
					}
				}
			});
			$pcmenu.find('li > a').on('mouseenter focusin',function(e){
				  var num = $(this).parent().index();
				  active_num1 = num;
				  $pcmenu.find('li').removeClass('on');
				  $(this).parent().addClass('on');
				  $gnbwrap.show();
				  $gnb_dep1.hide();
				  $gnb_dep1.eq(num).show();
				  gnb_chk = true;
				  $wrap.addClass('dim');
				  maxH_set($gnb_dep1.eq(num).find('.depth2 .row-1'));
				  maxH_set($gnb_dep1.eq(num).find('.depth2 .row-2'));
				  maxH_set($gnb_dep1.eq(num).find('.depth2 .row-3'));
				  var $pro = $('.nav li:eq('+active_num1+')')
				  if($pro.hasClass('product')){
					 $('.nav-list > .product-banner').show();
				  }else{
					  $('.nav-list > .product-banner').hide();
				  }
				  //UI.ini.winLock();
				  UI.GNB.crumbs_reset();
			  });
			  $pcmenu.find('li > a').on('keydown',function(e){
				  if(e.which == 13){
					 //console.log('$pcmenu : ', e.which, active_num1, $gnb_dep1.eq(active_num1).children('.depth2').find('a:visible:first').html());
					 $nav.find('a:visible:first').focus();
				  }
			  }	);
			  $gnbmenu.on('keydown',function(e){
				  //console.log(e.which, key_math, focus_num);
				  if(e.which == 9 && key_math == true){
				     $pcmenu.find('li:eq('+focus_num+') > a').focus();
				  }
			  }	);
			  $gnbmenu.on('mouseenter focusin',function(e){
				  var $tar = $(e.target);
				  var $tar1 = $tar.closest('.depth2');
				  var $tar2 = $tar.closest('.depth3');
				  var $root = $tar.closest('.nav');
				  var path1 = $tar1.parent().index();
				  var path2 = $tar2.parent().index();
				  var path3 = $tar.parent().index();
				  var length2  = $root.children('li').eq(path1).find('.depth2 > li').length - 1;
				  var length3  = $tar2.find('li').length - 1;
				  if($tar2.is(':visible')){
					  if(path2 == length2 && path3 == length3){
						 focus_num = path1;
						 key_math = true;
					  }else{
						 key_math = false;
					  }
				  }else{
					  if(path3 == length2){
						 focus_num = path1;
						 key_math = true;
					  }else{
						 key_math = false;
					  }
				  }
				 //console.log('focusin : ', path1,path2,path3,' | ',length2,length3, $tar1.is(':visible'), $tar2.is(':visible'));
				  if($ham.is(':hidden')){
					  gnb_chk = true;
					  UI.GNB.interval();
				  }
			  });
			  $pcmenu.find('li > a').on('mouseleave focusout',function(){
				  if($ham.is(':hidden')){
					  gnb_chk = false;
					  UI.GNB.interval();
				  }
			  });
			  $gnbmenu.on('mouseleave focusout',function(){
				   if($ham.is(':hidden')){
					  gnb_chk = false;
					  UI.GNB.interval();
				   }
			  });
			  /*
			  $('.side-menu').on('mouseenter',function(){
				  var $this = $(this);
				  clearInterval(mypage_interval);
			  });
			  $('.side-menu').on('mouseleave',function(){
				  var $this = $(this);
				  mypage_interval = setTimeout(function(){
						$this.find('li').removeClass('on');
						$this.find('li:not(.active) .depth2').hide();
						$this.find('.nav > .active > ul').slideDown();
				   },300);
			  });
			  */
			  $crumbs.children('a').on('click',function(e){
			  	  var $par = $(this).parent();
			  	  if(!$par.hasClass('home')){
			  	  	  if($par.hasClass('open')){
			  	  	  	  $par.removeClass('open');
			  	  	  	  $par.children('.drop-menu').slideUp();
						  if($par.children('.drop-menu').hasClass('mCustomScrollbar')){
								 UI.customScroll.destroy($par.children('.drop-menu'));
						  }
			  	  	  }else{
			  	  	  	  $crumbs.filter('.open').children('.drop-menu').hide();
						  $crumbs.filter('.open').removeClass('open');
			  	  	  	  $par.addClass('open');
			  	  	  	  $par.children('.drop-menu').slideDown(function(){
							  if($(this).children('ul').height() > 500){
								 UI.customScroll.scrollY($par.children('.drop-menu'));
							  }
						  });

			  	  	  }
			  	  	  e.preventDefault();
			  	  }
			  });
		},
	  handler : function($tar, state){
		  if(!gnb_chk){
			  $gnbwrap.hide();
			  $wrap.removeClass('dim');
			  $pcmenu.find('li').removeClass('on');
			  $gnbwrap.find('.depth2 > li').removeAttr('style');
			  $gnb_dep1.show();
			  //UI.ini.winUnlock();
		  }
	  },
	  interval : function($tar, state){
		  var aaa =  setTimeout(function(){UI.GNB.handler();},100);
	  },
	  crumbs_reset:function(){
		$crumbs.removeClass('open').find('.drop-menu').hide();
		if($crumbs.find('.drop-menu').hasClass('mCustomScrollbar')){
			UI.customScroll.destroy($crumbs.find('.drop-menu'));
		}
	  }
	},
	PROADD: {
		init:function(){
			$proTar = $('.product-enroll');
			$proTar_sel =  $proTar.find('.pro-select');
			$btnAdd = $proTar.find('.btn-add');
			$proRemove = $proTar.find('.btn-remove');
			$add = $proTar_sel.find('.row');
			this.event();
		},
		event:function(){
			$doc.on('click','.btn-remove-row',function(e){
				var $this = $(e.currentTarget);
				var $tar = $this.closest('.row');
				$tar.remove();
				e.preventDefault();
			});
			$btnAdd.on('click',function(e){
				//$proTar_sel.append($add.parent().html());
				e.preventDefault();
			});
		}
	},
	LANG:{
		init:function(){
			$doc.on('click','.country dt > a',function(e){
				var $this = $(e.currentTarget);
				var $tar = $this.parent().parent();
				var $root = $this.closest('.country');
				if($ham.is(':visible')){
					if($tar.hasClass('open')){
						$tar.removeClass('open');
						$tar.children('dd').slideUp();
					}else{
						$root.find('.open').children('dd').slideUp();
						$root.children('dl').removeClass('open');
						$tar.addClass('open');
						$tar.children('dd').slideDown();
					}
				}
				e.preventDefault();
			});
		}
	},
	mobileTable : {
		init:function(){
			this.event();
		},
		event:function(){
			$doc.on('click','.total-open',function(e){
				var $this = $(e.currentTarget);
				var $acctable = $this.closest('.acc-table-list');
				$acctable.find('dl').each(function(){
					$(this).not('.on').addClass('on');
					$(this).find('dd').show();
				});
				e.preventDefault();
			});
			$doc.on('click','.total-close',function(e){
				var $this = $(e.currentTarget);
				var $acctable = $this.closest('.acc-table-list');
				$acctable.find('dl').each(function(){
					$(this).filter('.on').removeClass('on');
					$(this).find('dd').hide();
				});
				e.preventDefault();
			});
			$doc.on('click','.acc-table-list > .table dt > a',function(e){
				var $this = $(e.currentTarget);
				var $par = $this.closest('dl');
				if($par.hasClass('on')){
					$par.removeClass('on');
					$par.find('dd').slideUp();
				}else{
					$par.addClass('on');
					$par.find('dd').slideDown();
				}
				e.preventDefault();
			})
		}
	}
};
});
var MF = MF || {};
var MF = {
	init : function(){
		$mfwrap = $('.pop-finder');
		$tagwrap = $('.tag-wrap');
		$result = $('.result-wrap');
		MF.perform.init();
	},
	perform : {
		init : function(){
			$perform = $('.perform-wrap');
			this.event();
			this.set();
		},
		event : function(){
			$mfwrap.on('click','.btn-more',function(e){
				//console.log('btn-more')
				$('.tag').css({height:'auto'});
				e.preventDefault();
			});
			$tagwrap.on('click','.btn-reset',function(e){
				MF.perform.reset();
				e.preventDefault();
			});
			$perform.find('input:radio').on('click',function(){
				 MF.perform.hendler($(this));
			 });
			$doc.on('click','.tag > .btn-option',function(e){
				var $tar = $(this);
				var num = $tar.attr('data-num');
				$perform.find('li').eq(num).find('input:radio').prop("checked",false);
				$perform.find('li').eq(num).find('.ques .fc0').removeClass('abnormal');
				$perform.find('li').eq(num).find('.ques .num').show();
				$perform.find('li').eq(num).find('.ques .value').hide();
				$tar.remove();
				if($tagwrap.find('.btn-option').length == 0){
					MF.perform.reset();
				}
				e.preventDefault();
			});
		},
		hendler : function($this){
			var $li = $this.closest('li');
			var $par = $li.children('.ques');
			var val = $this.next().find('.val').text();
			var desc = $this.next().find('.desc').text();
			var _num = 'tag-'+$li.index();
			$par.find('.value').show();
			$par.find('.num').hide();
			$par.find('.val').text(val);
			$par.find('.desc').text(desc);
			$tagwrap.show();
			$tagwrap.find('.'+_num).remove();
			$tagwrap.find('.tag').prepend('<a href="#" class="btn-option '+ _num +'" data-num="' + $li.index() +'">' + val + ' <i class="btn-del">삭제</i></a>');
			if($this.hasClass('abnormal')){
				$par.find('.fc0').addClass('abnormal');
			}else{
				$par.find('.fc0').removeClass('abnormal');
			}
		},
		set : function(num){
			$perform.find('.accodian > li').each(function(index){
				var $this = $(this);
				var option_num = $this.find('input:radio').length;
				$this.find('.ques .num').show().text(option_num);
			});
	   },
	   reset : function(){
			$perform.find('input:radio').prop("checked",false);
			$tagwrap.find('.btn-option').remove();
			$perform.find('.ques .fc0').removeClass('abnormal');
			$perform.find('.ques .value').hide();
			$perform.find('.ques .num').show();
			$tagwrap.hide();
			$result.hide();
	   }
	}
}
//textarea
$.fn.getCursorPosition=function(){
	var el=$(this).get(0),pos=0;
	if("selectionStart" in el){
		pos=el.selectionStart;
	}else if("selection" in document){
		el.focus();
		var sel=document.selection.createRange(),selLength=document.selection.createRange().text.length;
		sel.moveStart("character",-el.value.length);
		pos=sel.text.length-selLength;
	}
	return pos;
}
//가로스크롤
function scrollX_w($tar){
	$tar.each(function(){
		var $scroll = $(this).closest('.mCSB_container');
		var n = $(this).children('li').length
		var t = parseInt($(this).children('li').css('padding-left'));
		var w = $(this).children('li').width();
		var s = 0
		if($('.btn-hamburger').is(':visible')){s = 26;}
		$(this).css({'width':(n*(t+w)) + s});
		$scroll.css({'width':(n*(t+w)) + s});
	});
}
function scrollY_set(){
	$('.scroll-xy').css({'height':winH - headerH});
}
//윈도우팝업
function windowPop(url, winW, winH, name){
	var winName = (name) ? name : "winPop";
	var winposX = (screen.width - winW) / 2;
	var winposY = (screen.height - winH) / 2;
	var option = "width=" + winW + ", height=" + winH + ", top=" + winposY + ", left=" + winposX + ", scrollbars=yes, toolbar=no, resizable=yes";
	console.log('windowPop : ',url,winName,option);
	window.open(url, winName, option);
}
//전체레이어팝업
function fullLayerPop(url){
	UI.ini.winLock();
	$('#wrapper').append('<div class="full-pop-wrap"></div>');
	$('.full-pop-wrap').load(url, function(){
		var $pop = $(this);
		$('.full-pop-wrap').on('click','.btn-pop-close',function(){
			$pop.remove();
			UI.ini.winUnlock();
		})
	});
}
//링크 레이어팝업
function linkLayerPop(id, url,func){
	var str = id.substring(1);
	$('#wrapper').append('<div class="layerpop-wrap link-type" id="' + str + '"></div>');
	$('.layerpop-wrap.link-type').load(url, function(){
		var $this = $(this);
		$this.find('.scroll-y').each(function(){
			var $par = $(this).closest('.pop-finder');
			if($par.length >= 1){
				if($body.hasClass('deviceDesk')){
					UI.customScroll.scrollY($(this));
				}
			}else{
				UI.customScroll.scrollY($(this));
			}
		});
		if(func == "finder"){
			//MF.init();
		}
		UI.POP.open($this);
	});
}
function pop_scollset(){
	var $this = $('.layerpop-wrap');
	$this.find('.scroll-y').each(function(){
		var $par = $(this).closest('.pop-finder');
		if($par.length >= 1){
			if($body.hasClass('deviceDesk')){
				UI.customScroll.scrollY($(this));
			}
		}else{
			UI.customScroll.scrollY($(this));
		}
	});
	$this.find('.search-bar input').focus();
}
//3Dviewer 팝업
function iframeLayerPop(id,url){
	var str = id.substring(1);
	var markup = '<div class="layerpop-wrap link-type iframe-pop" id="' + str + '">'
	markup +='<div class="pop-container" style="width:1000px;">'
	markup +='<div class="head">'
	markup +='<h2>'
	markup +='<div class="hgroup">3D viewer</div>'
	markup +='<div class="skew-bg"></div>'
	markup +=	'</h2>'
	markup +=	'<a href="#" class="btn-pop-close" title="Close"><i class="icon-pop-close revers"></i></a>'
	markup +='</div>'
	markup +='<div class="content" style="height:550px;">'
	markup +='<iframe src="' + url + '" width="100%" height="100%" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true" frameborder="0"></iframe>'
	markup +='</div></div></div>'
	$('#wrapper').append(markup);
	var $pop = $('#'+str);
	UI.POP.open($pop);
}
//제품찾기 마크업 변형
function pro_setting($tar){
	if($('.btn-hamburger').is(':visible')){
		$tar.each(function(){
			if(!$(this).hasClass('pop-init')){
				var $pop = $(this).wrap('<div class="layerpop-wrap"></div>').wrap('<div class="pop-container product-search"></div>').wrap('<div class="content"></div>');
				var $pop_cont = $(this).closest('.pop-container');
				$pop_cont.prepend('<div class="head"><h2><div class="hgroup">' + $.i18n.prop("FrontTL_100002338") + '</div><div class="skew-bg"></div></h2><a href="#" class="btn-pop-close" title="Close"><i class="icon-pop-close revers"></i></a></div>');
				$pop_cont.find('.content').append('<div class="btn-group align-center"><a href="#" class="btn bg0" onclick="pop_close_submit(this); return false;">' + $.i18n.prop("FrontTL_100002439") + '</a></div>');
				$(this).addClass('pop-init');
			}
		});
	}else{
		$tar.each(function(){
			if($(this).hasClass('pop-init')){
				var $pop = $(this).closest('.pop-container');
				$pop.find('.btn-group').remove();
				$pop.children('.head').remove();
				$(this).removeClass('pop-init');
				$(this).unwrap('<div class="content"></div>').unwrap('<div class="pop-container"></div>').unwrap('<div class="layerpop-wrap link-type"></div>');

			}
		});
	}
}
function pop_close_submit(obj){
	var $pop = $(obj).closest('.layerpop-wrap');
	//console.log('pop_close_submit ',obj, $pop);
	UI.POP.close($pop);
}
//max높이값 찾기
function maxH_set($tar){
	var max_h=0;
   $tar.each(function(){
		var h = parseInt($(this).css("height"));
		if(max_h<h){ max_h = h; }
   });
   $tar.each(function(){
	   $(this).css({'height':max_h});
   });
}
//모델시리즈 높이 셋팅
function maxBoxSet(){
	$('.max-h-fit').each(function(){
		var $max = $(this);
		$max.find('.max-h').removeAttr('style');
		var max_h=0;
		//console.log('maxHfit--------------------------',$max,$max.find('.max-h').index())
		$max.find('.max-h').each(function(){
			var h = parseInt($(this).css("height"));
			if(max_h<h){ max_h = h; }
		});
		$max.find('.max-h').each(function(){
		   $(this).css({'height':max_h});
		});
	});
}
//placeholders
function placeholders(){
  if($body.hasClass('ie9')){
	  $(":text, textarea").each(function(){
		  if( $(this).val() == ""){
			$(this).val($(this).attr("placeholder"));
		  }
	  });
  }
}
//loading
function loading_show(){
	//console.log('loading_show');
	$('body').append('<div class="loading-dimed"></div>');

}
function loading_remove(){
	//console.log('loading_remove');
	$('.loading-dimed').remove();
	setTimeout(function(){
		$(".ellipsis-muti").ellipsis();
		UI.customScroll.scrollY($('.perform-wrap.scroll-y'));
	},500);
}
//motionInit
function motionInit($obj, num){
	var space = 100;
	var dir = $obj.attr('data-motion');
	//console.log('motionInit',mobile);
	if(!mobile){
		if(!$obj.hasClass('ani-end')){
			if(dir == 'btm-To-up'){
				TweenMax.fromTo($obj, 0.7, {y:space, opacity:0}, {y:0, opacity:1, delay:num*0.2});
			}else if(dir == 'up-To-btm'){
				TweenMax.fromTo($obj, 0.7, {y:-space, opacity:0}, {y:0, opacity:1, delay:num*0.2});
			}else if(dir == 'left-To-right'){
				TweenMax.fromTo($obj, 0.7, {x:-space, opacity:0}, {x:0, opacity:1, delay:num*0.2});
			}else if(dir == 'right-To-left'){
				TweenMax.fromTo($obj, 0.7, {x:space, opacity:0}, {x:0, opacity:1, delay:num*0.2});
			}else{
				TweenMax.to($obj, 0.7, {opacity:1});
			}
			$obj.addClass('ani-end');
		}
	}
}
//anchor
function anchorFn(id){
	var tar_top = $(id).offset().top;
	var space = $('#header').height() + 20;
	var dur = 500;
	//console.log(id, tar_top, space);
	$('html, body').stop().animate({'scrollTop':tar_top - space},dur);
}
$(function(){
	//ie 하위 브라우져 공지
	if(Browser.ie6 || Browser.ie7 || Browser.ie8){
		var cookiedata = document.cookie;
		console.log('ie 하위 브라우져 공지',cookiedata.indexOf("updatePop=done"));
		if(cookiedata.indexOf("updatePop=done") < 0){
			/*
			var markup = '<div id="brwUpdatePop" class="layerpop-wrap link-type" style="display:block;">'
				 markup += '<div class="pop-container browser-ie9" style="width:1000px;">'
				 markup += '<div class="head">'
				 markup += '<h2><div class="hgroup">권장 브라우저 안내</div></h2>'
				 markup += '<a href="#"  class="btn-pop-close" title="Close"><i class="icon-pop-close revers"></i></a>	'
				 markup += '</div>'
				 markup +=	'<div class="content">'
				 markup +=	'<div class="privacy-box">'
				 markup += '<p class="h4">오토닉스 웹 사이트에 최적화된 브라우저는 <span class="h4 fc0">Internet Explorer 10 이상</span>입니다.</p>'
				 markup += '<p class="desc">Internet Explorer 10이하 버전 사용 시,3D CAD 뷰어, 화면 레이아웃이 정상적으로 보이지 않을 수 있습니다. <br>편리한 사이트 이용을 위해, 최신 브라우저로 업그레이드를 권장합니다.</p>'
				 markup += '<img src="/images/common/icon-ie9.jpg" alt="browser img" class="img" />'
				 markup += '</div>'
				 markup += '<div class="btn-group in-big">'
				 markup += '<a href="https://www.microsoft.com/ko-kr/download/internet-explorer.aspx" target="_blank" title="' + $.i18n.prop('FrontTL_100002360') + '" class="btn btn-lg bg0">Internet Explorer 업그레이드</a>'
				 markup += '<a href="https://www.google.co.kr/chrome/browser/desktop/index.html" target="_blank" title="' + $.i18n.prop('FrontTL_100002360') + '" class="btn btn-lg bg0">chrome 업그레이드</a>'
				 markup += '<a href="https://support.apple.com/ko_KR/downloads/safari" target="_blank" title="' + $.i18n.prop('FrontTL_100002360') + '" class="btn btn-lg bg0">Safari 업그레이드</a>'
				 markup += '</div></div>'
				 markup += '<div class="cookie-wrap align-right"><input type="checkbox" name="chkbox" id="cookie"><label for="cookie"><span></span>오늘 하루 보지 않기</label></div>'
				 markup += '</div></div>'
			$('#wrapper').append(markup);
			*/
			$('#brwUpdatePop').show();
			$('body').append('<div class="document-dimed"></div>');
		}
	}
	var load_cnt = 0;
	var guide = String(location.href).split('/');
	var ext = guide[guide.length-1].split('.');
	if(ext[1] && ext[1].substring(0,4) == 'html'){
		if(guide[4] == 'HTMLguide'){
			UI.init();
		}else{
			if($('html').attr('lang') =='zh'){ //중국
				$("#header").load("/html/include/header-cn.html",function(){
					load_finish();
				 });
			}else if($('html').attr('lang') == 'en'){ //영어(글로벌, 미국, 인도, 말레이시아)
				$("#header").load("/html/include/header-in.html",function(){
					load_finish();
				 });
			}else if($('html').attr('lang') == 'in'){ //인도네시아
				$("#header").load("/html/include/header-id.html",function(){
					load_finish();
				 });
			}else if($('html').attr('lang') == 'ja'){ //일본
				$("#header").load("/html/include/header-jp.html",function(){
					load_finish();
				 });
			}else if($('html').attr('lang') == 'ms'){// 말레이시아
				$("#header").load("/html/include/header-my.html",function(){
					load_finish();
				 });
			}else if($('html').attr('lang') == 'vi'){//베트남
				$("#header").load("/html/include/header-vn.html",function(){
					load_finish();
				 });
			}else if($('html').attr('lang') == 'th'){//태국어
				$("#header").load("/html/include/header-th.html",function(){
					load_finish();
				 });
			}else if($('html').attr('lang') == 'pt'){//브라질
				$("#header").load("/html/include/header-br.html",function(){
					load_finish();
				 });
			}else if($('html').attr('lang') == 'es'){//스페인어(멕시코,콜롬비아, 페루, 칠레, 베네수엘라, 에콰도르, 라틴아메리카)
				$("#header").load("/html/include/header-mx.html",function(){
					load_finish();
				 });
			}else if($('html').attr('lang') == 'ru'){//러시아
				$("#header").load("/html/include/header-ru.html",function(){
					load_finish();
				 });
			}else if($('html').attr('lang') == 'tr'){//터키
				$("#header").load("/html/include/header-tr.html",function(){
					load_finish();
				 });
			}else if($('html').attr('lang') == 'uk'){//우크라이나
				$("#header").load("/html/include/header-ua.html",function(){
					load_finish();
				 });
			}else if($('html').attr('lang') == 'fa'){ //이란
				$("#header").load("/html/include/header-ir.html",function(){
					load_finish();
				 });
			}else{
				$("#header").load("/html/include/header.html",function(){
					load_finish();
				 });
			}
			 $("#footer").load("/html/include/footer.html",function(){
				load_finish();
			 });
			 $(".crumbs").load("/html/include/crumbs.html",function(){
				load_finish();
			 });
			 $("#smartbar-wrap").load("/html/include/smartbar.html",function(){
				 //html include 시점으로 인해 여기서 호출함 추후 ui.js 주석부분 해제후 삭제
				 var core = window[APP_NAME];
				 core.SMARTBAR = core.ui('smartbar','#smartbar-wrap')[0];
				 /*
				  * autonics.SMARTBAR.appendItem(category,html);
				  * autonics.SMARTBAR.removeItem(category,itemIndex);
				  * category 1 = '최근 본 제품';
				  * category 2 = '관심 제품';
				  * category 3 = '제품 비교';
				  * category 4 = '다운로드 보관함';
				  * html = '<li>.......</li>';
				  */
			 });
		}
	}else{
		UI.init();
		if($('#smartbar-wrap').index() >= 0){
			var core = window[APP_NAME];
			core.SMARTBAR = core.ui('smartbar','#smartbar-wrap')[0];
			 /*
			  * autonics.SMARTBAR.appendItem(category,html);
			  * autonics.SMARTBAR.removeItem(category,itemIndex);
			  * category 1 = '최근 본 제품';
			  * category 2 = '관심 제품';
			  * category 3 = '제품 비교';
			  * category 4 = '다운로드 보관함';
			  * html = '<li>.......</li>';
			  */
		}
	}
	function load_finish(){
	 load_cnt++;
	 if(load_cnt == 3){
		 UI.init();
	 }
	}
});

var keys = {37: 1, 38: 1, 39: 1, 40: 1};

function preventDefault(e) {
  e = e || window.event;
  if (e.preventDefault)
      e.preventDefault();
  e.returnValue = false;
}

function preventDefaultForScrollKeys(e) {
    if (keys[e.keyCode]) {
        preventDefault(e);
        return false;
    }
}
//스크롤 잠금
function disableScroll() {
  if (window.addEventListener) // older FF
      window.addEventListener('DOMMouseScroll', preventDefault, false);
  window.onwheel = preventDefault; // modern standard
  window.onmousewheel = document.onmousewheel = preventDefault; // older browsers, IE
  window.ontouchmove  = preventDefault; // mobile
  document.onkeydown  = preventDefaultForScrollKeys;
}
//스크롤 해제
function enableScroll() {
    if (window.removeEventListener)
        window.removeEventListener('DOMMouseScroll', preventDefault, false);
    window.onmousewheel = document.onmousewheel = null;
    window.onwheel = null;
    window.ontouchmove = null;
    document.onkeydown = null;
}
if (mobile) {
	//Pinch Zoom 끄기
	document.documentElement.addEventListener('touchstart', function (event) {
		if (event.touches.length > 1) {
		  event.preventDefault();
		}
	}, false);
	//Double tab Zomm 끄기
	var lastTouchEnd = 0;
	document.documentElement.addEventListener('touchend', function (event) {
		var now = (new Date()).getTime();
		if (now - lastTouchEnd <= 300) {
		  event.preventDefault();
		}
		lastTouchEnd = now;
	}, false);
}
//app 구분
var na = window.navigator;
var ua = na.userAgent;
$(function(){
	var agentType = $('body').data('client-type');
	if(agentType != 'app'){
		//iphoneX체크
		if (navigator.userAgent.match(/(iPhone)/)){
		  if((screen.availHeight == 812) && (screen.availWidth == 375)){
			  //iphoneX 크롬
			  if(ua.indexOf('CriOS') != -1){
					//TweenMax.set($('#smartbar-wrap a'),{y:-24});
					$('#smartbar-wrap').addClass('chorme');
			  }	
			  $('body').addClass("iphoneX");
			}else{
			  $('body').removeClass("iphoneX");
			}
		}
	}
	//app
	if(agentType == 'app'){
		$('a[target=_blank]').on('click',function(e){
			e.preventDefault();
			var $this = $(this);
			var href = $this.attr('href');
			if(href.substring(0,1) == "/"){
				window.Native.openOutWebpage(location.origin + href);
			}else{
				window.Native.openOutWebpage(href);
			}

		});
	}
});
