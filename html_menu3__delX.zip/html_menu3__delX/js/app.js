var ajaxLoadImg = true;

/**
 * Number.prototype.format(n, x)
 *
 * @param integer n: length of decimal
 * @param integer x: length of sections
 */
Number.prototype.format = function(n, x) {
    var re = '\\d(?=(\\d{' + (x || 3) + '})+' + (n > 0 ? '\\.' : '$') + ')';
    return this.toFixed(Math.max(0, ~~n)).replace(new RegExp(re, 'g'), '$&,');
};

Number.prototype.show = function(max) {
	if(max == undefined) max = 99;
    return (this < max ? this : max+"+");
};

if (!String.prototype.repeat) {
	String.prototype.repeat = function(count) {
		'use strict';
    	if (this == null) {
    		throw new TypeError('can\'t convert ' + this + ' to object');
    	}
    	var str = '' + this;
    	count = +count;
    	if (count != count) {
    		count = 0;
    	}
    	if (count < 0) {
    		throw new RangeError('repeat count must be non-negative');
    	}
    	if (count == Infinity) {
    		throw new RangeError('repeat count must be less than infinity');
    	}
    	count = Math.floor(count);
    	if (str.length == 0 || count == 0) {
    		return '';
    	}
    	if (str.length * count >= 1 << 28) {
    		throw new RangeError('repeat count must not overflow maximum string size');
    	}
    	var rpt = '';
    	for (var i = 0; i < count; i++) {
    		rpt += str;
    	}
    	return rpt;
	}
}

var app = (function($) {

	var init = function(option) {
		console.log('app.init()');
		// 다국어메시지 로딩
		jQuery.i18n.properties({
				name : 'messages',
			path : '/locale/',
			mode : 'both',
			language : option.locale,
			callback : function() {
				UI.ini.resizeWin();  
			}
		});

		/* ajax start , end Method
		 */
		$(document).ajaxStart(function(e){
			console.log("ajax start - " + ajaxLoadImg)
			if(ajaxLoadImg && $(".loading-dimed").length == 0) {
				loading_show();
			}
		});

		$(document).ajaxStop(function(){
			if($(".loading-dimed").length > 0) {
				loading_remove();
			}
			ajaxLoadImg = true;
		});

		// 비동기 로그인 요청
		$(document).ajaxError(function (event, xhr, thr){
			if(xhr.status == 401){
				// alert($.i18n.prop('msg_cms_200000153'));
				alert('로그인이 필요합니다.');
				location.href="/login?autoUrl=" + encodeURI(location.href);
				return;
			} else {
				if(thr.url != "/inc/log") {
					alert('데이터 처리 도중 에러가 발생하였습니다.');
				} else {
				}
			}
			ajaxLoadImg = true;
		});

		// vaildata alter 변경
		$.extend( $.validator.defaults, {
			 invalidHandler: function(form, validator) {
				var errors = validator.numberOfInvalids();
				if (errors) {
					alert(validator.errorList[0].message);
					var errEle = validator.errorList[0].element;
					// CK EDITOR 경우
					if($(errEle).prop("tagName")=="TEXTAREA" && $(errEle).next().hasClass("cke")) {
						CKEDITOR.instances[$(errEle).next().attr("id").replace("cke_","")].focus();
					// FILE 경우
					//} else if ($(errEle).attr('type') === "file" && $(errEle).data('style') === "fileinput"){
					//	$(validator.errorList[0].element).click();
					} else {
						validator.errorList[0].element.focus();
					}
				}
			},
			ignore: [], // CKEDITOR가 텍스트 영역을 숨기므로 jQuery 유효성 검사는 요소의 유효성을 검사하지 않습니다.
			onkeyup:false,
			onfocusout:false,
		    showErrors:function(errorMap, errorList){
	            /*if(this.numberOfInvalids()) { // 에러가 있을 때만..
	                alert(errorList[0].message);
	                $(errorList[0].element).focus()
	            }*/
	        },
			errorPlacement: function(error, element) {
				/*if (element.attr('type') === "file" && element.data('style') === "fileinput"){
					error.appendTo(element.closest("div.fileinput-holder").parent('div'));
				} else if (element.data('parent_class')) {
					error.appendTo(element.parents('.'+element.data('parent_class')));
				} else {
					error.insertAfter(element)
				}*/
			}
		});

	};

	return {
		init: init
	};
}(jQuery));


/**
 * vaildator 공백 처리
 * */
(function ($) {
    $.each($.validator.methods, function (key, value) {
        $.validator.methods[key] = function () {
            if(arguments.length > 0) {
                arguments[0] = $.trim(arguments[0]);
            }

            return value.apply(this, arguments);
        };
    });
} (jQuery));

$(document).ready(function (){
	$(".numberOnly").on("keydown", function (event){
    	var code = event.which;
    	if ((code >= 48 && code <= 57) || (code >= 96 && code <= 105) || (code==8) || (code==9) || (code==46) || (code==13)) {
    	} else {
    		alert($.i18n.prop('FrontTL_100002473'));	// 숫자만 입력가능합니다.
    		event.preventDefault();
    		$(this).val($(this).val().substring(0, $(this).val().length));
    	}
    });
});

