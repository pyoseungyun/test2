$(function(){
	//visual slide
	var visual_swiper;
	$(window).on('resize',function(){
		mainResize();
	});
	mainResize();
	visual_loading_show();
	if($('.big-banner .swiper-slide').length <= 1){
		$('.big-banner .swiper-slide').css({'width':'100%'}).addClass('swiper-slide-active');
		swiperSet();
		swiperMotion();
		$('.big-banner').css({'opacity':1});
		$('.big-banner .visual-prev').hide();
		$('.big-banner .visual-next').hide();
	}else{
		visual_swiper = new Swiper('.swiper-container',{
			pagination: '.visual-pagination',
			loop:true,
			autoplay: 5000,
			paginationClickable: true,
			autoplayStopOnLast: true,
			calculateHeight : true, 
			resizeReInit: true,
			simulateTouch:false,
			onInit: function(swiper){
				setTimeout(function(){
					if($('.visual-pagination .btn-ctl').index() < 0){
						console.log('onInit');
						$('.visual-pagination').append('<a href="#" class="btn-ctl"></a>');						
						visual_loading_remove();
						swiperSet();
						swiperMotion();
					}
					$('.big-banner').css({'opacity':1});
				},10);				
				$('.big-banner').css({'opacity':1});
				if($('html').attr('lang') == 'fa'){
					$('.visual-pagination').attr('dir','rtl');
				}
				
			},
			onSlideChangeStart: function(swiper){
				swiperSet();
				//console.log('onSlideChangeStart');
				TweenMax.set($('.big-banner .bg'),{x:0});
				$('.big-banner .title').css({'opacity':0});
				$('.big-banner .desc').css({'opacity':0});
				$('.big-banner .bar').css({'opacity':0});
				$('.big-banner .btn').css({'opacity':0});
			},
			onSlideChangeEnd : function(swiper){
				//console.log('onSlideChangeEnd');
				swiperMotion();
			}
		});
		$('.big-banner .visual-prev').on('click',function(e){
			visual_swiper.swipePrev();
			e.preventDefault();	
		});
		$('.big-banner .visual-next').on('click',function(e){
			visual_swiper.swipeNext();
			e.preventDefault();	
		});
	}
	function mainResize(){	
		var visualW = $('.big-banner').width();
		var $bg = $('.big-banner img.bg');
		//console.log('visualW', visualW);
		if(visualW > 1800){
			$bg.css({'left':0,'width':visualW+100,'margin-left':0,'opacity':1});
		}else{
			$bg.css({'left':'50%','width':2000,'margin-left':-1000,'opacity':1});
		}
	}
	$(document).on('click','.visual-pagination .swiper-pagination-switch', function(e){
		var $this = $('.visual-pagination .btn-ctl');
		if(!$this.hasClass('play')){
			visual_swiper.startAutoplay();
		}		
	});
	$(document).on('click','.visual-pagination .btn-ctl', function(e){
		var $this = $(e.currentTarget);
		if($this.hasClass('play')){
			visual_swiper.startAutoplay();
			$this.removeClass('play');
		}else{
			visual_swiper.stopAutoplay();
			$this.addClass('play');
		}
		e.preventDefault();			
	});
	function swiperSet(){				
		$('.visual-pagination').removeClass('t-white');
		if($('.big-banner .swiper-slide-active').hasClass('t-white')){
			$('.visual-pagination').addClass('t-white');
		}
	}
	function swiperMotion(){	
		var bgX = -100;
		var lineW = 500;
		var $title = $('.big-banner .swiper-slide-active .title');
		var $desc = $('.big-banner .swiper-slide-active .desc');
		var $bar = $('.big-banner .swiper-slide-active .bar');
		var $btn = $('.big-banner .swiper-slide-active .btn');
		if($('.btn-hamburger').is(':visible')){
			lineW=300;
		}else{
			TweenMax.to($('.big-banner .swiper-slide-active .bg'),6,{x:bgX,delay:0.5});
		}
		//console.log('bgX : ', bgX," : ", slideW);		
		TweenMax.fromTo($bar,0.5,{opacity:0,width:0},{opacity:1,width:lineW,ease:Power3.easeOut});
		TweenMax.fromTo($title,1,{opacity:0,y:30},{opacity:1,y:0,ease:Power2.easeOut,delay:0.2});
		TweenMax.to($bar,0.5,{width:50,ease:Power3.easeOut,delay:1});
		TweenMax.fromTo($desc,0.8,{opacity:0,y:-30},{opacity:1,y:0,ease:Power2.easeOut,delay:0.5});
		TweenMax.fromTo($btn,1,{opacity:0},{opacity:1,ease:Power2.easeOut,delay:1});
	}
	//product line
	$(document).on('click','.skew-tab a', function(e){
		var $this = $(e.currentTarget).parent();
		var num = $(this).attr('class').substring(6,7);
		var $line_c = $('.product-line').find('.line-c' + num)
		$('.skew-tab .tab > li').removeClass('active');
		$this.addClass('active');
		$('.product-line .scroll-x-list').removeClass('active');
		$line_c.addClass('active');
		scrollX_w($line_c);	
		$('.product-line .scroll-x').mCustomScrollbar("update");
		if($('html').attr('lang') == 'fa'){
			setTimeout(function(){$('.product-line .scroll-x').mCustomScrollbar("scrollTo","right",{scrollInertia:500});},100);
		}else{
			setTimeout(function(){$('.product-line .scroll-x').mCustomScrollbar("scrollTo","left",{scrollInertia:500});},100);
		}
		e.preventDefault();
		$('.product-line .ellipsis-muti').ellipsis();
	});	
	//finder toggle
	$(document).on('click','.finder-toggle, .product-finter .title', function(e){
		var $this = $(e.currentTarget).parent();
		if($this.hasClass('open')){
			$this.find('.finder-cont').slideUp();
			$this.removeClass('open');
		}else{
			$this.find('.finder-cont').slideDown();
			$this.addClass('open');
		}
		e.preventDefault();			
	});
	//pc-header
	$(document).on('click','.pc-header a', function(e){
		var $this = $(e.currentTarget).parent();
		var $head = $('.pc-header > li');
		$head.removeClass('on');
		$this.addClass('on');
		$('.product-finter > div').removeClass('on');
		if($this.hasClass('model')){					
			$('.model-cont').addClass('on');
		}else{
			$('.motor-cont').addClass('on');
		}
		e.preventDefault();			
	});	
	//resize
	var winW = $(window).innerWidth();
	$(window).on('resize',function(){
		winW = $(this).innerWidth();
		tab_init();
		industry_scrollset();
		if($('.btn-hamburger').is(':visible')){
			m_scroll();
		}
	});	
	function tab_init(){
		var $tab = $('.product-line .tab > li');
		if(!$('.product-line .select-value').is(':visible')){
			$tab.css({'width':(100/$tab.length)+'%'});
			$('.main .product-line .tab-wrap .tab li:before')
		}
	}	
	//swiper-industry		
	var industry_initial = 0; 
	if($('html').attr('lang') == 'fa'){
		$('.swiper-industry .swiper-wrapper').attr('dir','rtl'); 
		industry_initial = $('.swiper-industry').find('.swiper-slide').length-1; 
	}else{
		$('.swiper-industry .swiper-wrapper').removeAttr('dir'); 
	}

	var isIndustry; 
	var industry_swiper;
	var mobile = (/iphone|ipod|ipad|android|blackberry|mini|windows\sce|palm/i.test(navigator.userAgent.toLowerCase()));
	//alert('mobile 체크 : ' + mobile);
	if(mobile){
		$('.swiper-industry > div').removeClass('swiper-wrapper').css({'width':($('.swiper-industry .swiper-slide').width()*$('.swiper-industry .swiper-slide').length)+15});
		//alert('mobile :' + $('.swiper-industry .swiper-wrapper').width());
	}else{
		industry_swiper = new Swiper('.swiper-industry',{ 
			autoplayStopOnLast: true, 
			calculateHeight : true, 
			slidesPerView : 3, 
			resizeReInit : true, 
			initialSlide  : industry_initial 
		}); 
		$(document).on('click','.industry-prev', function(e){
			if($('html').attr('lang') == 'fa'){
				industry_swiper.swipeNext();	
			}else{
				industry_swiper.swipePrev();
			}			
			e.preventDefault();			
		});
		$(document).on('click','.industry-next', function(e){			
			if($('html').attr('lang') == 'fa'){
				industry_swiper.swipePrev();
			}else{			
				industry_swiper.swipeNext();	
			}
			e.preventDefault();			
		});
		industry_scrollset();	
	}
	function industry_scrollset(){
		if($('.btn-hamburger').is(':visible') || winW < 1024){ 	
			if(isIndustry) return; 
			isIndustry = true; 
			industry_swiper.params.onlyExternal = true; 
			industry_swiper.reInit(); 
			industry_swiper.swipeTo(0,0,false);	
			UI.customScroll.scrollX($('.swiper-industry'));
			if($('html').attr('lang') == 'fa'){
				setTimeout(function(){$('.swiper-industry').mCustomScrollbar("scrollTo","right",{scrollInertia:500});},100);
			}
			m_scroll();
		}else{ 
			if(!isIndustry) return; 
			if($('.swiper-industry').hasClass('mCustomScrollbar')){ 
				UI.customScroll.destroy($('.swiper-industry')); 
				//$('.swiper-industry').mCustomScrollbar("disable"); 
				$('.swiper-industry').show(); 
			} 
			isIndustry = false; 
			//console.log('mCustomScrollbar',$('.swiper-industry .mCSB_container').index())
			industry_swiper.params.onlyExternal = false; 
			industry_swiper.reInit();
			//alert($('.swiper-industry .swiper-slide').width()*$('.swiper-industry .swiper-slide').length);
			$('.swiper-industry .swiper-wrapper').removeAttr('style');
			$('.swiper-industry .swiper-wrapper').css({'width':$('.swiper-industry .swiper-slide').width()*$('.swiper-industry .swiper-slide').length});
		} 
	} 
	function m_scroll(){
		var w = ($('.swiper-industry .swiper-slide').width()*$('.swiper-industry .swiper-slide').length)+20 ;		
		$('.swiper-industry .mCSB_container').css({'width':w});		
		$('.swiper-industry .swiper-wrapper').css({'min-width':$('.swiper-industry .mCSB_container').width(),'padding-left':10});
		//console.log('.swiper-industry .swiper-wrapper',$('.swiper-industry .mCSB_container').width());
	}
	//init
	tab_init();
	
});

//loading
function visual_loading_show(){
	//console.log('loading_show');
	$('.big-banner').append('<div class="loading-dimed visual"></div>');

}
function visual_loading_remove(){
	console.log('loading_remove');
	$('.big-banner .loading-dimed').remove();
}