/*
 *	common
 */
(function (context, $, undefined) {
	"use strict";

    var APP_NAME = window.APP_NAME = 'autonics';
	var core = context[ APP_NAME ] || (context[ APP_NAME ] = {});

	core.$win = $(window);
	core.$doc = $(document);

	/*
	 * browser detect || (core.browser[object])
	 */
	core.browser = (function(){
		var detect = {},
			win = context,
			na = win.navigator,
			ua = na.userAgent,
			lua = ua.toLowerCase(),
			match;

		detect.isMobile = typeof orientation !== 'undefined';
		detect.isTouch = !!('ontouchstart' in win);
		detect.isRetina = 'devicePixelRatio' in win && win.devicePixelRatio > 1;
		detect.isAndroid = lua.indexOf('android') !== -1;
		detect.isOpera = win.opera && win.opera.buildNumber;
		detect.isWebKit = /WebKit/.test(ua);
		detect.rtl = (document.dir !== 'rtl') ? false : true;

		return detect;
	})();

	/*
	 * screen detect || (core.screen[object]);
	 * core.screen.width = window resizeAfter width;
	 */
	core.screen = (function(){
		var detect = {};
		detect.width = core.$win[0].innerWidth;
		detect.height = core.$win[0].innerHeight;

		core.$win.on('resize',function(){
			detect.width = core.$win[0].innerWidth;
		});
		return detect;
	})();

	/*
	 * Selector
	 * var selector = core.Selector(container,{
			content : '.inner > .content',    //css Selector Sizzle
		});
		selector.$content = $(container).find('.inner > .content');
	 */
	core.Selector = function(container,selector){
		var $container = $(container),
			selectors = {},
			i;
		for(i in selector){
			selectors['$'+i] = $container.find(selector[i]);
		}
		selectors.$container = $container;
		return selectors;
	}

	/*
	 * var core = window[APP_NAME];
	 * var smartbar = core.ui('smartbar'//ui.functionName,'#smartbar-wrap'//ui container selector);
	 * smartbar[0].method();
	 */
	core.ui = function(name, container){
		var $container = $(container);
		if(!$container.length) return false;

		var supr = {};
		$container.each(function(idx){
			supr[idx] = new core.ui[name](this);
		});
		return supr;
	}

	core.getParameters = function(paramName){
		var returnValue,
	    	url = location.href,
	    	parameters = (url.slice(url.indexOf('?') + 1, url.length)).split('&');

	    for (var i = 0; i < parameters.length; i++) {
	        var varName = parameters[i].split('=')[0];
	        if (varName.toUpperCase() == paramName.toUpperCase()) {
	            returnValue = parameters[i].split('=')[1];
	            return decodeURIComponent(returnValue);
	        }
	    }
	}
})(this, jQuery);

/*
 *	core.ui
 */
(function($, core, ui, undefined){
	
	ui.smartbar = function(container){
		var selector = core.Selector(container,{
			smtBody : '.smtbar >.body',
			smtBodyInner : '.smtbar > .body > .inner',
			smtHead : '.smtbar >.head',
			btnTop : '.head .btn-top',
			headToggle : '.head .btn-toggle',
			bodyToggle : '.body .btn-toggle',
			menuLi : '.head .smart-menu >li',
			menuBtn : '.head .smart-menu >li > a',
			btnToggle : '.head .btn-toggle',
			smtCon : '.body .smt-con',
			slideWrap : '.body .slide-wrap',
			slideCon : '.body .slide-wrap .slide-con'
		});
		var origScrollLeft = jQuery.fn.scrollLeft;
		jQuery.fn.scrollRight = function(i) {
			var value = origScrollLeft.apply(this, arguments);
			if (i === undefined) {
				if(core.browser.rtl){
					return this[0].scrollWidth - value - this[0].clientWidth;
				}
			}

			return value;
		};
		
		
		var SLIDER = {};
		var detect = {};
		var events = {
			_init : function(){
				this._bindEvent();		//event Binding
				this._initSlider();		//init Slider
				this._requestMenu();	//request Param Tab Active
				this._initCrisp();
			},
			_bindEvent : function(){
				selector.$btnTop.on("click",this._browserTop);
				selector.$menuBtn.on('click',this._menuOpen);
				selector.$headToggle.on('click',this._menuClose);
				selector.$bodyToggle.on('click',this._menuClose);
			},
			_initCrisp : function(){
				window.CRISP_READY_TRIGGER = function() { //crips ReadyCallback
					selector.$crispIcon = $('.crisp-client .crisp-113f7m5');
					//selector.$crispIcon.attr('style','bottom:50px !important');
					if(selector.$menuLi.hasClass('on')){
						events._handleCripsPosition('open',true);
					}
				};
			},
			_initSlider : function(){
				selector.$slideWrap.each(function(idx){
					SLIDER[idx] = new events.Slider(this);
				});
			},
			_requestMenu : function(){
				var menu = core.getParameters('smartbar');
				if(menu !== undefined){
					selector.$menuLi.eq(--menu).children('a').trigger('click');
				}
			},
			_browserTop : function(e){
				e.preventDefault();
				$('html,body').stop().animate({
					"scrollTop" : 0
				},700);
			},
			_menuClose : function(e){	//body Slide Hide
				e.preventDefault();
				//if(!$(this).hasClass('close')) return;
				//selector.$smtBody.slideUp();
				if(!$(this).hasClass('close')){
					selector.$menuBtn.eq(0).trigger("click");
				}else{
					selector.$menuLi.filter('.on').removeClass('on');
					selector.$btnToggle.removeClass('close');
					selector.$smtBody.slideUp({
	                    duration: 400,
	                    easing: "easeOutQuad"
	                });
					events._handleCripsPosition('close'); //Crips
				};
			},
			_menuOpen : function(e){
				e.preventDefault();
				var $li = $(this).parent();
				if($li.hasClass('on')) return;
				var idx = $li.index();

				selector.$menuLi.filter('.on').removeClass('on');
				$li.addClass('on');
				selector.$btnToggle.addClass('close');

				selector.$smtCon.hide().eq(idx).show();
				
				if(!core.browser.rtl) selector.$smtCon.eq(idx).find('.slide-con').scrollLeft(0);
				else selector.$smtCon.eq(idx).find('.slide-con').scrollLeft(9999);

				events._handleCripsPosition('open'); //Crips
				selector.$smtBody.slideDown({
                    duration: 400,
                    easing: "easeOutQuad"
                });

				if(SLIDER[idx]) SLIDER[idx].init();
			},
			_handleCripsPosition : function(action, isReady){
				var $cripsIcon = $('.crisp-client .crisp-113f7m5');
				var _y = (action !== 'open') ?  0 : -selector.$smtBody.outerHeight();
				if(isReady){ //crisp Loaded Position
					TweenMax.set($cripsIcon,{y:_y});
					return;
				}
				TweenMax.to($cripsIcon,.4,{y:_y});
			},
			Slider : function(container){ //Slider
				var slider = core.Selector(container,{
					slideCon : '.slide-con',
					slideItem : '.slide-con > li',
					slideItemFirst : '.slide-con > li:first',
					slideItemLast : '.slide-con > li:last',
					btnPrev : '.btn-prev',
					btnNext : '.btn-next'
				});
				
				var rtl = ($('html').attr('dir') == 'rtl') ? true : false;
				var idx = 0;
				var sliderMethod = {
					OffsetRight : function($wrap,$target){
						return $wrap.width() - $target.offset().left + $target.outerWidth();
					}
				}
				var sliderEvent = {
					init : function(){
						sliderEvent._resizeDetect();
						sliderEvent._detectScroll();
					},
					_goSlide : function(e){
						e.preventDefault();
						if(slider.isAni || $(this).hasClass('disable')) return;
						slider.isAni = true;
						var dir = e.data.dir + slider.step;
						idx = idx+e.data.idx;
						
						TweenMax.to(slider.$slideCon,.5,{scrollLeft:dir,
							onComplete:sliderEvent._slideEnd
						});
					},
					_slideEnd : function(){
						slider.isAni = false;
						sliderEvent._detectScroll();
					},
					_touchEvent : function(e){
						var type = e.type;
						switch(type){
							case 'touchstart' :
								disableScroll();
								
								TweenMax.killTweensOf(slider.$slideCon);
								slider.startX = e.originalEvent.changedTouches[0].pageX;
								slider.scrollX = slider.$slideCon.scrollLeft();
								
							break;
							case 'touchmove' :
								TweenMax.killTweensOf(slider.$slideCon);
								slider.moveX = slider.startX - e.originalEvent.changedTouches[0].pageX;
								slider.distX = (slider.moveX + slider.scrollX);

								TweenMax.to(slider.$slideCon,.2,{scrollLeft:slider.distX,ease:Power2.easeOut,
									onComplete:function(){
										setTimeout(function(){
											slider.lastX = (!core.browser.rtl) ? slider.$slideCon.scrollLeft() : slider.$slideCon.scrollRight();
											slider.selectedGap = (slider.lastX / slider.step).toFixed(1);
											slider.selectedIndex = Math.floor(slider.selectedGap);
											slider.selectedX = slider.selectedIndex * slider.step;
											
											if(core.browser.rtl){
												var scrArea = slider.$slideCon[0].scrollWidth - slider.$slideCon[0].clientWidth;
												slider.selectedX = scrArea - slider.selectedX;
											}
											
											TweenMax.to(slider.$slideCon,.2,{scrollLeft:slider.selectedX,
												onComplete:sliderEvent._detectScroll
											});
										},100);
									}
								});
							break;
							case 'touchend' : 
								enableScroll();
							break;
						}
					},
					_detectScroll : function(){
						if(!slider.$slideCon.children().length) return;

						slider.$slideItemFirst = slider.$slideCon.children().first();
						slider.$slideItemLast = slider.$slideCon.children().last();
						
						function prevCheck(){
							if(!rtl){
								if(slider.$slideItemFirst.position().left > -1) slider.$btnPrev.addClass('disable');
								else slider.$btnPrev.removeClass('disable');
							}else{
								if(slider.$slideItemFirst.position().left < slider.$slideCon.width()){
									slider.$btnPrev.addClass('disable');
								}else{
									slider.$btnPrev.removeClass('disable');
								}
							}
						}
						function nextCheck(){
							if(!rtl){
								var right = sliderMethod.OffsetRight(slider.$slideCon,slider.$slideItemLast);
								var rightRange = (!slider.isMobile) ? 0 : slider.step;
								var rightMax = (right > rightRange) ? true : false;

								if(rightMax){
									slider.lastCheck = true;
									slider.$btnNext.addClass('disable');
								}else{
									slider.lastCheck = false;
									slider.$btnNext.removeClass('disable');
								}
							}else{
								var rightMax = (slider.$slideCon.scrollLeft() < slider.step) ? true : false;
								
								if(rightMax){
									slider.lastCheck = true;
									slider.$btnNext.addClass('disable');
								}else{
									slider.lastCheck = false;
									slider.$btnNext.removeClass('disable');
								}
							}
						}
						
						prevCheck();
						nextCheck();
						slider.slideLeft = slider.$slideCon.scrollLeft();
					},
					_resizeEvent : function(){
						sliderEvent._resizeDetect();
						sliderEvent._fixedScroll();
					},
					_resizeDetect : function(){
						if(core.screen.width < 1024){
							slider.isMobile = true;
							slider.step = 90;
						}else{
							slider.isMobile = false;
							slider.step = 160;
						}
					},
					_fixedScroll : function(){
						slider.$slideCon.scrollLeft(slider.slideLeft);
					},
					_removeItem : function(index, callback){
						var $target = slider.$slideCon.children().eq(index);
						slider.scrollLeft = slider.$slideCon.scrollLeft();
						TweenMax.to($target,.5,{scale:0,opacity:0,
							onComplete:function(){
								$target.remove();
								slider.$slideCon.scrollLeft(slider.scrollLeft-slider.step);
								sliderEvent._detectScroll();
								if(typeof(callback) === "function") {
									callback();
								}
							}
						});
					},
					_appendItem : function(html){
						slider.isAni = true;
						/*var html = '<li class="new">';
							html +=	'<a href="#">';
							html += '<img src="/images/temp/temp10.jpg" alt="대체텍스트">';
							html += '<p class="ellipsis">3AiS SeriesAiS SeriesAiS SeriesAiS Series</p>';
							html += '</a>';
							html += '<a href="#" class="btn icon line2 btn-remove" title="삭제하기"><i class="btn-del">삭제하기</i></a>';
							html += '</li>';*/
						var $html = $(html);
						TweenMax.set($html,{opacity:0,scale:0});

						// 마지막 append
						//slider.$slideCon.append($html);
						//slider.$slideItemLast = slider.$slideCon.children().last();
						// first append
						slider.$slideCon.prepend($html);
						slider.$slideItemLast = slider.$slideCon.children().first();

						slider.scrollLeft = slider.$slideCon.scrollLeft();

						var a = slider.$slideItemLast.offset().left - slider.$slideCon.width();
						var b = (!slider.isMobile) ? Math.floor(a/slider.step) : Math.ceil(a/slider.step);
						var c = b * slider.step + slider.scrollLeft;

						TweenMax.to(slider.$slideCon,.5,{scrollLeft:c,
							onComplete:function(){
								TweenMax.to($html,.3,{opacity:1,scale:1,
									onComplete:sliderEvent._slideEnd
								});
							}
						});
					}
				}
				
				sliderEvent.init();
				if(!core.browser.rtl){
					slider.$btnPrev.on('click',{dir:'-=',idx:-1},sliderEvent._goSlide);
					slider.$btnNext.on('click',{dir:'+=',idx:+1},sliderEvent._goSlide);
				}else{
					slider.$btnPrev.on('click',{dir:'+=',idx:-1},sliderEvent._goSlide);
					slider.$btnNext.on('click',{dir:'-=',idx:+1},sliderEvent._goSlide);
				}
				
				slider.$slideCon.on('touchstart touchmove touchend',sliderEvent._touchEvent);
				core.$win.on('load resize',sliderEvent._resizeEvent);

				return{
					init : function(){
						sliderEvent._resizeDetect();
						sliderEvent._detectScroll();
					},
					appendItem : function(html){
						sliderEvent._appendItem(html);
					},
					removeItem : function(index, callback){
						sliderEvent._removeItem(index, callback);
					}
				};
			}
		}
		events._init();

		return {
			appendItem : function(category, html){
				selector.$menuLi.eq(category-1).children('a').trigger('click');
				SLIDER[category-1].appendItem(html);
			},
			removeItem : function(category, index, callback){
				SLIDER[category-1].removeItem(index, callback);
			}
		}
	}
})(jQuery, window[APP_NAME], window[APP_NAME].ui);

$(function(){
	//var core = window[APP_NAME];
	//core.SMARTBAR = core.ui('smartbar','#smartbar-wrap');
});







