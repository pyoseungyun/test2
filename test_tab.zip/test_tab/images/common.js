
$(function(){
	
	// tabs
	var tabs = $('.tabs ul li');
	tabs.bind('click', function (){
		$('.disnone').css('display','none');
		var idName = $(this).children('a').attr('id');
		$('div.' + idName).css('display','block');

		for(var i=0; i<$('.tabs ul li').length; i++){
			$('.tabs ul li').eq(i).removeClass('on');
			$(this).addClass('on');
		}
	});

	var astabs = $('.asTabs ul li');
	astabs.bind('click', function (){ 
		$('.disnone').css('display','none');
		var idName = $(this).children('a').attr('id');
		$('div.' + idName).css('display','block');

		for(var i=0; i<$('.asTabs ul li').length; i++){
			$('.asTabs ul li').eq(i).removeClass('on');
			$(this).addClass('on');
		}
	});
	
	
});